import setuptools
import os


def __path(filename):
    return os.path.join(os.path.dirname(__file__), filename)


build = 0

if os.path.exists(__path('VERSION')):
    build = open(__path('VERSION')).read().strip()

version = build

setuptools.setup(
    name="patternmatch",
    version=version,
    description="patternmatch package",
    url="https://repos.currenciesdirect.com:8443/scm/lapetus/patternmatch.git",
    packages=setuptools.find_packages(),
    include_package_data=True,
    package_data={'requirement': ['requirements.txt']},
    data_files=[('requirement', ['requirements.txt']),
                ('patternmatchmain', ['run.py'])],
    scripts=['run.py'],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    requires=['postgres', 'flask', 'dateutil', 'pandas'],
    python_requires='>=3.6'
)
