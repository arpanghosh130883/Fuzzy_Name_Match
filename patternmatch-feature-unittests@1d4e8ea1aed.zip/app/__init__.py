import json
from app.main import app
from app.controller import application
from flask import Flask, render_template, redirect, url_for, jsonify, request
from flask_bootstrap import Bootstrap
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired

application_init = application('Pattern Match')

Bootstrap(app)


class NameForm(FlaskForm):
    name = StringField('Enter text for pattern match on affiliate', validators=[DataRequired()])
    submit = SubmitField('Submit')


@app.route('/affiliate', methods=['GET', 'POST'])
def index():
    form = NameForm()
    message = ""
    match_value = ""
    aff_no_msg = ""
    affiliate_number = ""
    if form.validate_on_submit():
        name = form.name.data
        result = application_init.matching_func(str_to_match=name)
        result_dict = json.loads(result[0])
        if 'match_value' in result_dict:
            match_value = result_dict['match_value']
            affiliate_number = result_dict['affiliate_number']
            message = "Matching affiliate is :"
            aff_no_msg = "Affiliate number is :"
        else:
            message = "No match found!"
    return render_template('index.html', match_value=match_value, affiliate_number=affiliate_number,
                           form=form, message=message, aff_no_msg=aff_no_msg)


@app.route('/patmatch/v1/affiliate/match', methods=['GET', 'POST'])
def index2():
    if request.method == 'POST':
        application_init.logger.logger_info(' into post request')
        try:
            request_json = request.get_json()
            response_json = application_init.matching_func(request_json['referral_text'])
            return response_json
        except Exception as e:
            application_init.logger.logger_error(e)
            return jsonify({'message': 'Bad Request'}), 400
    else:
        application_init.logger.logger_error('request parameter is not correct')
        return jsonify({'message': 'Bad Request'}), 400
