import logging


class BaseConfig(object):
    DEBUG = False
    TESTING = False
    LOGGING_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    LOGGING_LEVEL = logging.INFO
    LOGGING_LOCATION = 'patternmatch.log'
    SECRET_KEY = 'secret_key_1329932432423'
    CASSANDRA_HOSTS = ''
    CASSANDRA_PORT = 9042
    CASSANDRA_USER = ''
    CASSANDRA_PASSWORD = ''
    CASSANDRA_KEYSPACE = ''
    CSRF_ENABLED = True


class ProdConfig(BaseConfig):
    DEBUG = False
    TESTING = False
    CASSANDRA_HOSTS = ['10.0.12.74', '10.0.12.75', '10.0.12.215']
    CASSANDRA_PORT = 9042
    CASSANDRA_USER = 'fpadmin'
    CASSANDRA_PASSWORD = '5p@dm!n1'
    CASSANDRA_KEYSPACE = 'refined_zone'


class DevelopmentConfig(BaseConfig):
    DEBUG = False
    TESTING = False
    CASSANDRA_HOSTS = ['172.31.4.177', '172.31.4.182', '172.31.4.183']
    CASSANDRA_PORT = 9042
    CASSANDRA_USER = ''
    CASSANDRA_PASSWORD = ''
    CASSANDRA_KEYSPACE = 'refined_zone_uat'


class UatConfig(BaseConfig):
    DEBUG = False
    TESTING = False
    CASSANDRA_HOSTS = ['172.31.4.177', '172.31.4.182', '172.31.4.183']
    CASSANDRA_USER = ''
    CASSANDRA_PASSWORD = ''
    CASSANDRA_KEYSPACE = 'refined_zone_uat'


class LocalConfig(BaseConfig):
    DEBUG = True
    TESTING = True
    LOGGING_LEVEL = logging.DEBUG
    CASSANDRA_HOSTS = ['127.0.0.1']
    CASSANDRA_USER = ''
    CASSANDRA_PASSWORD = ''
    CASSANDRA_KEYSPACE = 'refined_zone_uat'


class TestConfig(BaseConfig):
    DEBUG = True
    TESTING = True
    LOGIN_DISABLED = True
    CASSANDRA_HOSTS = ['172.31.4.177', '172.31.4.182', '172.31.4.183']
    CASSANDRA_PORT = 9042
    CASSANDRA_USER = ''
    CASSANDRA_PASSWORD = ''
    CASSANDRA_KEYSPACE = 'refined_zone_test'
