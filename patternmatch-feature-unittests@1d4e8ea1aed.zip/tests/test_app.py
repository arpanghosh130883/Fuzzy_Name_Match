import unittest
import os
import datetime
import json
from app.main import app
from app.controller import application
from app.db_model import db_connection, affiliate_master, affiliate_match_response


class TestApp(unittest.TestCase):
    def setUp(self):
        self.application = application("test app")
        self.application.testing = True
        app.config['TESTING'] = True
        os.environ['CQLENG_ALLOW_SCHEMA_MANAGEMENT'] = '1'
        self.client = app.test_client()

        aff_master = affiliate_master(acc_sf_id='0010X00004TRVl', contact_sf_id='0030X00002V',
                                      affiliate_name='AKA Africa', affiliate_number='A093064',
                                      contact_name='Jerome Andrews',
                                      loaded_date=datetime.datetime.now(), org='Currencies Direct')
        affiliate_master.save(aff_master)
        print('connected')

    def tearDown(self):
        pass
        # affiliate_master(acc_sf_id='0010X00004TRVl').delete()

    def test_route_affiliate(self):
        result = self.client.get('/affiliate', follow_redirects=True)
        self.assertEqual(result.status_code, 200)

    def test_route_patmatch_affiliate_match_not_found(self):
        request_json = {"referral_text": "bobin oz"}
        result = self.client.post('/patmatch/v1/affiliate/match', data=json.dumps(request_json),
                                  content_type='application/json')
        self.assertEqual(result.status_code, 404)

    def test_route_patmatch_affiliate_get_match(self):
        request_json = {"referral_text": "Jerom Andrews"}
        result = self.client.post('/patmatch/v1/affiliate/match', data=json.dumps(request_json),
                                  content_type='application/json')
        self.assertEqual(result.status_code, 200)

    def test_route_patmatch_affiliate_get_method(self):
        result = self.client.get('/patmatch/v1/affiliate/match', follow_redirects=True)
        self.assertEqual(result.status_code, 400)


if __name__ == '__main__':
    unittest.main()
