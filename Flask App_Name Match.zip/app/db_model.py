import datetime
import uuid
from cassandra.cqlengine import columns
from cassandra.cqlengine import connection
from cassandra.cqlengine import management
from cassandra.cqlengine.models import Model
from cassandra.auth import PlainTextAuthProvider
from cassandra.cluster import Cluster
from app.main import app


def db_connection():
    auth_provider = PlainTextAuthProvider(username=app.config['CASSANDRA_USER'], password=app.config['CASSANDRA_USER'])
    cluster = Cluster(contact_points=app.config['CASSANDRA_HOSTS'], auth_provider=auth_provider)
    session = cluster.connect()
    db_session = connection.register_connection('cluster', session=session)
    return db_session


class affiliate_master(Model):
    __keyspace__ = 'refined_zone_uat'
    __connection__ = 'cluster'
    acc_sf_id = columns.Text(primary_key=True)
    contact_sf_id = columns.Text(primary_key=True)
    affiliate_name = columns.Text()
    affiliate_number = columns.Text()
    contact_name = columns.Text()
    loaded_date = columns.DateTime()
    org = columns.Text()


class affiliate_match_response(Model):
    __keyspace__ = 'refined_zone_uat'
    __connection__ = 'cluster'
    referral_text = columns.Text(partition_key=True, primary_key=True)
    match_time = columns.DateTime(primary_key=True, default=datetime.datetime.utcnow())
    id = columns.UUID(primary_key=True, default=uuid.uuid4)
    match_value = columns.Text()
    affiliate_number_match = columns.Text()
    affiliate_name_match = columns.Text()
    contact_name_match = columns.Text()
    fuzzy_token_sort_ratio = columns.Integer()
    lev_ratio = columns.Integer()
