import logging


class logger_util:

    def __init__(self, name=__name__):
        self.name = name
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)

        # stream fileHandler
        streamHandler = logging.StreamHandler()
        streamHandler.setLevel(logging.DEBUG)

        # create a logging format
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        streamHandler.setFormatter(formatter)
        self.logger.addHandler(streamHandler)

    # info
    def logger_info(self, message):
        # add the handlers to the logger
        self.logger.info(message)

    # warning
    def logger_warning(self, message):
        # add the handlers to the logger
        self.logger.warning(message)

    # error
    def logger_error(self, message):
        # add the handlers to the logger
        self.logger.error(message)
