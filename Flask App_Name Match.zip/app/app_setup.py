import os
from flask import Flask
from .config import ProdConfig, DevelopmentConfig, LocalConfig, UatConfig

settings = {
    "Development": "DevelopmentConfig",
    "Local": "LocalConfig",
    "Prod": "ProdConfig",
    "UAT": "UatConfig",
    "default": "LocalConfig"
}


def create_app():
    app = Flask(__name__)

    # Flask-WTF requires an encryption key - the string can be anything
    app.config['SECRET_KEY'] = 'C2HWGVoMGfNTBsrYQg8EcMrdTimkZfAb'
    config_name = os.getenv('FLASK_ENV', 'default')

    print('ENV :' + str(config_name))
    app.config.from_object(eval(settings[config_name]))
    app.config.from_pyfile('config.cfg', silent=True)

    return app
