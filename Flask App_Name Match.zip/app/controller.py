import json
from fuzzywuzzy import fuzz
from fuzzywuzzy import process
import pandas as pd
from .db_model import db_connection, affiliate_master, affiliate_match_response
from app.logger_util import logger_util
import re

class application:

    def __init__(self, name):
        self.name = name
        self.logger = logger_util("main_" + str(name))
        self.logger.logger_info("__init__ end")
        self.connection = db_connection()
        self.affiliate_name_list, self.contact_name_list, self.affiliate_master_df = self.fetch_data_from_db()

    def fetch_data_from_db(self):
        try:
            affiliate_name_list = list()
            contact_name_list = list()
            affiliate_no_list = list()

            for records in affiliate_master.objects().all().limit(None):
                affiliate_name_list.append(records.affiliate_name)
                contact_name_list.append(records.contact_name)
                affiliate_no_list.append(records.affiliate_number)

            affiliate_master_df = pd.DataFrame(
                {'affiliate_name': affiliate_name_list, 'contact_name': contact_name_list,
                 'affiliate_number': affiliate_no_list})
            self.logger.logger_info('len of data fetched from table')
            self.logger.logger_info(affiliate_master_df.shape)
            return affiliate_name_list, contact_name_list, affiliate_master_df
        except ConnectionError as CE:
            self.logger.logger_error(CE)

    # creating a function to check for the fuzzy name using token_set_ratio and Lev distance
    def matching_func(self, str_to_match):
        response_dict = dict()
        self.logger.logger_info(str_to_match)
        str_to_match = str_to_match.strip()
        try:
            if str_to_match in self.affiliate_name_list:
                response_dict['referral_text'] = str_to_match
                response_dict['affiliate_name_match'] = str_to_match
                response_dict['match_value'] = str_to_match
                response_dict['contact_name_match'] = None
                response_dict['fuzzy_token_sort_ratio'] = 100
                response_dict['lev_ratio'] = 100
            else:
                x = process.extractOne(str_to_match, self.affiliate_name_list, scorer=fuzz.token_sort_ratio)
                y = process.extractOne(str_to_match, self.affiliate_name_list, scorer=fuzz.ratio)

                if (x[1] > y[1]) :
                    response_dict['referral_text'] = str_to_match
                    response_dict['affiliate_name_match'] = x[0]
                    response_dict['match_value'] = x[0]
                    response_dict['contact_name_match'] = None
                    response_dict['fuzzy_token_sort_ratio'] = x[1]
                    response_dict['lev_ratio'] = y[1]
                else:
                    response_dict['referral_text'] = str_to_match
                    response_dict['affiliate_name_match'] = y[0]
                    response_dict['match_value'] = y[0]
                    response_dict['contact_name_match'] = None
                    response_dict['fuzzy_token_sort_ratio'] = x[1]
                    response_dict['lev_ratio'] = y[1]

            if not (response_dict['fuzzy_token_sort_ratio'] >= 92 or response_dict['lev_ratio'] >= 92) :
                if str_to_match in self.contact_name_list:
                    response_dict['referral_text'] = str_to_match
                    response_dict['affiliate_name_match'] = None
                    response_dict['match_value'] = str_to_match
                    response_dict['contact_name_match'] = str_to_match
                    response_dict['fuzzy_token_sort_ratio'] = 100
                    response_dict['lev_ratio'] = 100
                else:

                    if (x[1] > y[1]):
                        x = process.extractOne(str_to_match, self.contact_name_list, scorer=fuzz.token_sort_ratio)
                        y = process.extractOne(str_to_match, self.contact_name_list, scorer=fuzz.ratio)
                        response_dict['referral_text'] = str_to_match
                        response_dict['affiliate_name_match'] = None
                        response_dict['match_value'] = x[0]
                        response_dict['contact_name_match'] = x[0]
                        response_dict['fuzzy_token_sort_ratio'] = x[1]
                        response_dict['lev_ratio'] = y[1]
                    else:
                        x = process.extractOne(str_to_match, self.contact_name_list, scorer=fuzz.token_sort_ratio)
                        y = process.extractOne(str_to_match, self.contact_name_list, scorer=fuzz.ratio)
                        response_dict['referral_text'] = str_to_match
                        response_dict['affiliate_name_match'] = None
                        response_dict['match_value'] = y[0]
                        response_dict['contact_name_match'] = y[0]
                        response_dict['fuzzy_token_sort_ratio'] = x[1]
                        response_dict['lev_ratio'] = y[1]

            # find affiliate no
            if response_dict['affiliate_name_match'] is None:
                affiliate_number = self.affiliate_master_df.loc[
                    self.affiliate_master_df['contact_name'] == response_dict[
                        'contact_name_match'], 'affiliate_number'].values[0]
                affiliate_name = self.affiliate_master_df.loc[
                    self.affiliate_master_df['contact_name'] == response_dict[
                        'contact_name_match'], 'affiliate_name'].values[0]
                response_dict['match_value'] = affiliate_name
                response_dict['affiliate_number'] = affiliate_number
            elif response_dict['contact_name_match'] is None:
                affiliate_number = self.affiliate_master_df.loc[
                    self.affiliate_master_df['affiliate_name'] == response_dict[
                        'affiliate_name_match'], 'affiliate_number'].values[0]
                response_dict['affiliate_number'] = affiliate_number

            self.logger.logger_info(response_dict)
            # data save in cassandra
            try:
                affiliateMatch = affiliate_match_response(referral_text=response_dict['referral_text'],
                                                          match_value=response_dict['match_value'],
                                                          affiliate_number_match=response_dict['affiliate_number'],
                                                          affiliate_name_match=response_dict['affiliate_name_match'],
                                                          contact_name_match=response_dict['contact_name_match'],
                                                          fuzzy_token_sort_ratio=response_dict[
                                                              'fuzzy_token_sort_ratio'],
                                                          lev_ratio=response_dict['lev_ratio'])
                affiliate_match_response.save(affiliateMatch)
                self.logger.logger_info('data saved into affiliate_match table')
            except ConnectionError as CE:
                self.logger.logger_error(CE)
            final_dict = {your_key: response_dict[your_key] for your_key in ['match_value', 'affiliate_number']}
            response = json.dumps(final_dict)
            response = response, 200
            self.logger.logger_info('json response created')
        except Exception as e:
            response_dict = {'affiliate_name': 'match not found'}
            response = json.dumps(response_dict)
            response = response, 404
            self.logger.logger_error(e)

        return response

