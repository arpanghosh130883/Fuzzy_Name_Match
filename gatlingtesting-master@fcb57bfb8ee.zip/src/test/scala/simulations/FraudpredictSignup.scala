package simulations

import io.gatling.core.Predef._
import io.gatling.http.Predef._

import scala.concurrent.duration._
import scala.util.Random

class FraudpredictSignup extends Simulation  {

  private def getProperty(propertyName: String, defaultValue: String) = {
    Option(System.getenv(propertyName))
      .orElse(Option(System.getProperty(propertyName)))
      .getOrElse(defaultValue)
  }

  def userCount: Int = getProperty("USERS", "5").toInt
  def rampDuration: Int = getProperty("RAMP_DURATION", "10").toInt
  def testDuration: Int = getProperty("DURATION", "60").toInt
  def responseTimeMax: Int = getProperty("MAX_RESPONSE_TIME_MS", "100").toInt

  before {
    println(s"Running test with ${userCount} users")
    println(s"Ramping users over ${rampDuration} seconds")
    println(s"Total test duration: ${testDuration} seconds")
    println(s"Max response time for test: ${responseTimeMax} ms")
  }

  val rnd = new Random()

  def randomString(length: Int) = {
    rnd.alphanumeric.filter(_.isLetter).take(length).mkString
  }

  val customFeeder = Iterator.continually(Map(
    "email" -> (randomString(5) + "@loadtest.test"),
    "cust_number" -> (rnd.nextInt(10000)),
    "ip_address" -> (rnd.nextInt(216) + "."+rnd.nextInt(216) + "." + rnd.nextInt(216) + "."+rnd.nextInt(216)),
    "ref_text" -> ("Ref-" + randomString(4)),
    "eid_status" -> rnd.nextInt(10)
  ))


  // 1 Http Conf
  val httpConf = http
    .baseUrl("https://uat-ml-api/")
    .header("Accept", "application/json")

  def postNewPayout() = {
    forever() {
      feed(customFeeder)
        .exec(http("Post New Signup")
          .post("/fraudpredict/v1/signup")
          .body(ElFileBody("SignupRequestPayload.json")).asJson
          .check(status.is(200)))
        .pause(2)
    }
  }

  val scn = scenario("Post new signup")
    .exec(postNewPayout())

  setUp(
    scn.inject(
      nothingFor(5 seconds),
      atOnceUsers(5),
      //      rampUsers(20) during (30 seconds)
      rampUsers(userCount) during (rampDuration second)
    ).protocols(httpConf)
  ).maxDuration(testDuration second)
    .assertions(
      global.responseTime.max.lt(100),
      global.successfulRequests.percent.gt(95)
    )
}
