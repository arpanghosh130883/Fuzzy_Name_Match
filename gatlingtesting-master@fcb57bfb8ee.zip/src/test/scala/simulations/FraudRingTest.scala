package simulations

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._


class FraudRingTest extends Simulation {

  private def getProperty(propertyName: String, defaultValue: String) = {
    Option(System.getenv(propertyName))
      .orElse(Option(System.getProperty(propertyName)))
      .getOrElse(defaultValue)
  }

  def userCount: Int = getProperty("USERS", "5").toInt
  def rampDuration: Int = getProperty("RAMP_DURATION", "10").toInt
  def testDuration: Int = getProperty("DURATION", "60").toInt
  def responseTimeMax: Int = getProperty("MAX_RESPONSE_TIME_MS", "100").toInt

  before {
    println(s"Running test with ${userCount} users")
    println(s"Ramping users over ${rampDuration} seconds")
    println(s"Total test duration: ${testDuration} seconds")
    println(s"Max response time for test: ${responseTimeMax} ms")
  }


  // 1 Http Conf
  val httpConf = http.baseUrl("https://uat-ml-api/fraudring/v1/get_ring/")
//  val httpConf = http.baseUrl("http://localhost:8080/fraudring/v1/check_is_fraud_ring_present/")
    .header("Accept", "application/json")

  val feeder = csv("customers.csv").random


  def getFraudRing() = {
    feed(feeder).exec(
      http("Get FR count")
        .get("${customerNumber}")
        .check(status.is(200))
    )
  }

  val scn = scenario("Basic Load Simulation")
    .forever() {
      exec(getFraudRing())
        .pause(2)
    }

  setUp(
    scn.inject(
      nothingFor(5 seconds),
      atOnceUsers(5),
      rampUsers(userCount) during (rampDuration second)
    ).protocols(httpConf)
  ).maxDuration(testDuration second)
    .assertions(
      global.responseTime.max.lt(responseTimeMax),
      global.successfulRequests.percent.gt(95)
    )

}
