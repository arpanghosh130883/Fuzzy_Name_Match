To run - Follow below syntax

mvn gatling:test '-Dgatling.simulationClass=simulations.FraudRingTest' -DUSERS=10 -DRAMP_DURATION=5 -DDURATION=30